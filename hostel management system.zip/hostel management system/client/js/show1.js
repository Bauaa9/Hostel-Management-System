var button1=document.querySelector("#Proceed");
var num=document.querySelector("#roomchange");
var num1=num.textContent;
button1.addEventListener("click",function () {
	// body...
	num1--;
	location.href="/payment";
	num.textContent=num1;
});
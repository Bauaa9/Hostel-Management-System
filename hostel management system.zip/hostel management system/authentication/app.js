var express=require("express");
var mongoose=require("mongoose");
var passport=require("passport");
var bodyParser=require("body-parser");
var passportLocal=require("passport-local");
var passportLocalMongoose=require("passport-local-mongoose");
var user=require("./models/user");
mongoose.connect("mongodb://localhost/roomimages");
var app=express();
app.set("view engine","ejs");
app.use(bodyParser.urlencoded({extended:true}));
app.use(require("express-session")({
	secret:"Rohit is a good boy",
	resave:false,
	saveUninitialized:false
}));
app.use(passport.initialize());
app.use(passport.session());
passport.use(new passportLocal(user.authenticate()));
passport.serializeUser(user.serializeUser());
passport.deserializeUser(user.deserializeUser());


app.get("/",function (request,response) {
	// body...
	response.render("home");
});
app.get("/secret",isLogged,function (request,response) {
	// body...
	response.render("secret");
});
app.get("/register",function (request,response) {
	// body...
	response.render("register");
});
app.post("/register",function (request,response) {
	// body...
	user.register(new user({username:request.body.username}),request.body.password,function (err,user) {
		// body...
		if(err){
			console.log(err);
			return response.render("register");
		}
		passport.authenticate("local")(request,response,function () {
			// body...
			response.redirect("/secret");
		});
	});
});
app.get("/login",function (request,response) {
	// body...
	response.render("login");
});
app.post("/login",passport.authenticate("local",{
	successRedirect:"/secret",
	failureRedirect:"/login"
}),function (request,response) {
	// body...
});
app.get("/logout",function (request,response) {
	// body...
	request.logout();
	response.redirect("/login");
});
function isLogged(request,response,next) {
	// body...
	if(request.isAuthenticated()){
		return next();
	}
	response.redirect("/login");
}
app.listen(5000,function () {
	// body...
	console.log("server has started");
});

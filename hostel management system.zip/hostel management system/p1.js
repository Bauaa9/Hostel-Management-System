var express=require("express");
var mongoose=require("mongoose");
var bodyParser=require("body-parser");
var passport=require("passport");
var flash=require("connect-flash");
var async=require("async");
var nodemailer=require("nodemailer");
var crypto=require("crypto");
var passportLocal=require("passport-local");
var passportLocalMongoose=require("passport-local-mongoose");	
var user=require("./models/user");
mongoose.connect("mongodb://localhost/modified");	
var app=express();
app.use(express.static(__dirname + '/public'));
app.use(express.static(__dirname + '/client'));
app.set("view engine","ejs");
app.use(bodyParser.urlencoded({extended:true}));
app.use(require("express-session")({
	secret:"Rohit is a good boy",
	resave:false,
	saveUninitialized:false
}));
app.use(flash());
app.use(passport.initialize());
app.use(passport.session());
passport.use(new passportLocal(user.authenticate()));
passport.serializeUser(user.serializeUser());
passport.deserializeUser(user.deserializeUser());


var roomImagesSchema= new mongoose.Schema({
	name:String,
	image:String,
	typeAc:String,
	gallery:String,
	typeOfRoom:String,
	typeOfBeds:String,
	price:Number,
	totalRooms:Number,
	count:Number,
	mess:String,
	bookroom:String
});

var roomImagesModel=mongoose.model("roomImagesModel",roomImagesSchema);
app.use(function (request,response,next) {
	// body...
	response.locals.currentUser=request.user;
	response.locals.error=request.flash("error");
	response.locals.success=request.flash("success");
	next();
});

app.get("/",function (request,response) {
	// body...
	response.render("landing");
})
app.get("/contact",function (request,response) {
	// body...
	response.render("contactpage");
});
app.post("/contact",function (request,response) {
	// body...
	response.redirect("/rohit");
});
app.get("/rohit/:id/payment",function (request,response) {
	// body...
	roomImagesModel.findById(request.params.id,function (err,findroomid) {
		// body...
		if (err) {
			console.log(err);
		} else {
			response.render("payment",{campground:findroomid});
		}
	});
});
app.post("/rohit/:id/payment",function (request,response) {
	// body...
	var query = { _id:request.params.id};
	roomImagesModel.update(query, { $inc: { totalRooms:-1}}, options={multi:true}, callback);
	roomImagesModel.update(query, { $inc: { count:1}}, options={multi:true}, callback);
	roomImagesModel.update({}, { $set: { bookroom:"Yes"}}, options={multi:true}, callback);

	function callback(err,unaffected) {
		// body...
		if (err) {
			console.log(err);
		}
		else {
			console.log("successfully updated");
		}
	}
	// console.log(request.params.id.price);
	response.render("landing");   
});

app.get("/rohit/:id/mess",function (request,response) {
	// body...
	roomImagesModel.findById(request.params.id,function (err,findroomid) {
		// body...
		if (err) {
			console.log(err);
		} else {
			response.render("messpayment",{campground:findroomid});	
		}		
	});
});

app.post("/rohit/:id/mess",function (request,response) {
	// body...
	var query = { _id:request.params.id};
	roomImagesModel.update({}, { $set: { mess:"Yes"}}, options={multi:true}, callback);

	function callback(err,unaffected) {
		// body...
		if (err) {
			console.log(err);
		}
		else {
			console.log("successfully updated");
		}
	}
	// console.log(request.params.id.price);
	response.render("landing");
});

app.get("/rohit",isLogged,function (request,response) {
	// body...
	roomImagesModel.find({},function (err,allrooms) {
		// body...
		if(err){
			console.log(err);
		}
		else{
			response.render("rohit",{arr:allrooms});		
		}
	});
})

app.get("/rohit/:id",function (request,response) {
	// body...
	roomImagesModel.findById(request.params.id, function (err,findroomid) {
		// body...
		if(err){
			console.log(err);
		} else {
			// request.flash("success","You have booked "+request.params.count+"rooms");
			response.render("show",{campground:findroomid});
		}
	});
	//response.render("show");
});

app.get("/rohit/:id/changeroom",function (request,response) {
	// body...
	roomImagesModel.findById(request.params.id,function (err,findroomid) {
		// body...
		if (err) {
			console.log(err);
		} else {
			response.render("changeroom",{campground:findroomid});
		}
	});
});
app.post("/rohit/:id/changeroom",function (request,response) {
	// body...
	roomImagesModel.update({}, { $set: { bookroom:"No"}}, options={multi:true}, callback);
	function callback(err,unaffected) {
		// body...
		if (err) {
			console.log(err);
		}
		else {
			console.log("successfully updated");
		}
	}
	// console.log(request.params.id.price);
	response.render("landing");
});
app.get("/profile",function (request,response) {
	// body...
	roomImagesModel.findById(request.params.id, function (err,findroomid) {
		// body...
		if(err){
			console.log(err);
		} else {
			// request.flash("success","You have booked "+request.params.count+"rooms");
			response.render("profile");
		}
	});
});
// auth routes
app.get("/register",function (request,response) {
	// body...
	response.render("register");
});
app.post("/register",function (request,response) {
	// body...
	var newUser=new user({username:request.body.username , email:request.body.email});
	user.register(newUser,request.body.password,function (err,user) {
		// body...
		if(err){
			request.flash("success","he");
			 response.render("register");
		}  else {
		passport.authenticate("local")(request,response,function () {
			request.flash("success","Thanks for signing up "+user.username +".Welcome!!!");
			response.redirect("/rohit");
		});
	}
	});
});

app.get("/login",function (request,response) {
	// body...
	response.render("login");
});
app.post("/login",passport.authenticate("local",{
	successRedirect:"/rohit",
	failureRedirect:"/login",
	// successFlash:"Welcome to the Hostel Management!",
}),function (request,response) {
	// body...
});

app.get("/forgot",function (request,response) {
	// body...
	response.render("forgot");
});

app.get("/logout",function (request,response) {
	// body...
	request.logout();
	request.flash("success","You have logout successfully");
	response.redirect("/");
});

function isLogged(request,response,next) {
	// body...
	if(request.isAuthenticated()){
		return next();
	}
	// request.flash("error","Invalid credentials.Please check again!!!");
	response.redirect("/login");
}





app.post('/forgot', function(req, res, next) {
  async.waterfall([
    function(done) {
      crypto.randomBytes(20, function(err, buf) {
        var token = buf.toString('hex');
        done(err, token);
      });
    },
    function(token, done) {
      user.findOne({ email: req.body.email }, function(err, user) {
        if (!user) {
          req.flash('error', 'No account with that email address exists.');
          return res.redirect('/forgot');
        }

        user.resetPasswordToken = token;
        user.resetPasswordExpires = Date.now() + 3600000; // 1 hour

        user.save(function(err) {
          done(err, token, user);
        });
      });
    },
    function(token, user, done) {
      var smtpTransport = nodemailer.createTransport({
        service: 'Gmail', 
        auth: {
          user: 'rohdge999@gmail.com',
          pass: "rohdge1234"
          // pass: process.env.GMAILPW
        }
      });
      var mailOptions = {
        to: user.email,
        from: 'rohdge999@gmail.com',
        subject: 'Password Reset',
        text: 'You are receiving this because you (or someone else) have requested the reset of the password for your account.\n\n' +
          'Please click on the following link, or paste this into your browser to complete the process:\n\n' +
          'http://' + req.headers.host + '/reset/' + token + '\n\n' +
          'If you did not request this, please ignore this email and your password will remain unchanged.\n'
      };
      smtpTransport.sendMail(mailOptions, function(err) {
        console.log('mail sent');
        req.flash('success', 'An e-mail has been sent to ' + user.email + ' with further instructions.');
        done(err, 'done');
      });
    }
  ], function(err) {
    if (err) return next(err);
    res.redirect('/forgot');
  });
});



app.get('/reset/:token', function(req, res) {
  user.findOne({ resetPasswordToken: req.params.token, resetPasswordExpires: { $gt: Date.now() } }, function(err, user) {
    if (!user) {
      req.flash('error', 'Password reset token is invalid or has expired.');
      return res.redirect('/forgot');
    }
    res.render('reset', {token: req.params.token});
  });
});

app.post('/reset/:token', function(req, res) {
  async.waterfall([
    function(done) {
      user.findOne({ resetPasswordToken: req.params.token, resetPasswordExpires: { $gt: Date.now() } }, function(err, user) {
        if (!user) {
          req.flash('error', 'Password reset token is invalid or has expired.');
          return res.redirect('back');
        }
        if(req.body.password === req.body.confirm) {
          user.setPassword(req.body.password, function(err) {
            user.resetPasswordToken = undefined;
            user.resetPasswordExpires = undefined;

            user.save(function(err) {
              req.logIn(user, function(err) {
                done(err, user);
              });
            });
          })
        } else {
            req.flash("error", "Passwords do not match.");
            return res.redirect('back');
        }
      });
    },
    function(user, done) {
      var smtpTransport = nodemailer.createTransport({
        service: 'Gmail', 
        auth: {
          user: 'rohdge999@gmail.com',
          pass: "rohdge1234"
        }
      });
      var mailOptions = {
        to: user.email,
        from: 'rohdge999@gmail.com',
        subject: 'Your password has been changed',
        text: 'Hello,\n\n' +
          'This is a confirmation that the password for your account ' + user.email + ' has just been changed.\n'
      };
      smtpTransport.sendMail(mailOptions, function(err) {
        req.flash('success', 'Success! Your password has been changed.');
        done(err);
      });
    }
  ], function(err) {
    res.redirect('/rohit');
  });
});



app.listen(4000,function () {
	// body...
	console.log("server has started");
})